from __future__ import annotations

import sqlite3
from typing import Any

from app.tables.common import create_row, delete_row, get_row, list_rows, update_row

TABLE_NAME = "LNG_ANNOTATIONS"
PK_COLUMN = "annotation_id"
WRITABLE_COLUMNS = {
    "label_type",
    "author_id",
    "audio_id",
    "relative_start",
    "relative_end",
    "abs_start_time",
    "abs_end_time",
    "asr_content",
    "vad_confidence",
    "is_annotated",
    "annotation_text",
    "annotation_time",
    "storage_tag",
    "next_id",
    "prev_id",
}

CREATE_SQL = f"""
CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
    annotation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    label_type TEXT,
    author_id INTEGER NOT NULL,
    audio_id INTEGER NOT NULL,
    relative_start REAL,
    relative_end REAL,
    abs_start_time TEXT,
    abs_end_time TEXT,
    asr_content TEXT,
    vad_confidence REAL,
    is_annotated INTEGER NOT NULL DEFAULT 0 CHECK(is_annotated IN (0,1)),
    annotation_text TEXT,
    annotation_time TEXT,
    storage_tag TEXT,
    next_id INTEGER,
    prev_id INTEGER,
    FOREIGN KEY(author_id) REFERENCES LNG_USERS(user_id),
    FOREIGN KEY(audio_id) REFERENCES LNG_AUDIO_RECORDS(audio_id),
    FOREIGN KEY(next_id) REFERENCES LNG_ANNOTATIONS(annotation_id),
    FOREIGN KEY(prev_id) REFERENCES LNG_ANNOTATIONS(annotation_id),
    CHECK(relative_start <= relative_end),
    CHECK(abs_end_time >= abs_start_time)
);
"""


def create_table(conn: sqlite3.Connection) -> None:
    conn.execute(CREATE_SQL)


def reset_table_data(conn: sqlite3.Connection) -> None:
    conn.execute(f"DELETE FROM {TABLE_NAME};")


def create_item(conn: sqlite3.Connection, payload: dict[str, Any]) -> int:
    return create_row(conn, TABLE_NAME, payload, WRITABLE_COLUMNS)


def get_item(conn: sqlite3.Connection, item_id: int) -> dict[str, Any] | None:
    return get_row(conn, TABLE_NAME, PK_COLUMN, item_id)


def list_items(conn: sqlite3.Connection, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
    return list_rows(conn, TABLE_NAME, limit, offset)


def update_item(conn: sqlite3.Connection, item_id: int, payload: dict[str, Any]) -> bool:
    return update_row(conn, TABLE_NAME, PK_COLUMN, item_id, payload, WRITABLE_COLUMNS)


def delete_item(conn: sqlite3.Connection, item_id: int) -> bool:
    return delete_row(conn, TABLE_NAME, PK_COLUMN, item_id)
