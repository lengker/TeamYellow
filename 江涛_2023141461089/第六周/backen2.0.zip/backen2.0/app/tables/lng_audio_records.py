from __future__ import annotations

import sqlite3
from typing import Any

from app.tables.common import create_row, delete_row, get_row, list_rows, update_row

TABLE_NAME = "LNG_AUDIO_RECORDS"
PK_COLUMN = "audio_id"
WRITABLE_COLUMNS = {
    "source_url",
    "start_time_utc",
    "end_time_utc",
    "duration_ms",
    "file_name",
    "file_path",
    "file_size",
    "status",
    "last_access_at",
    "track_id",
    "next_id",
    "prev_id",
}

CREATE_SQL = f"""
CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
    audio_id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_url TEXT NOT NULL,
    start_time_utc TEXT NOT NULL,
    end_time_utc TEXT NOT NULL,
    duration_ms INTEGER NOT NULL,
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size INTEGER,
    status INTEGER NOT NULL DEFAULT 0 CHECK(status IN (0,1,2,3)),
    last_access_at TEXT,
    track_id INTEGER NOT NULL,
    next_id INTEGER,
    prev_id INTEGER,
    FOREIGN KEY(track_id) REFERENCES LNG_TRACKS(track_id),
    FOREIGN KEY(next_id) REFERENCES LNG_AUDIO_RECORDS(audio_id),
    FOREIGN KEY(prev_id) REFERENCES LNG_AUDIO_RECORDS(audio_id),
    CHECK(end_time_utc >= start_time_utc)
);
"""


def create_table(conn: sqlite3.Connection) -> None:
    conn.execute(CREATE_SQL)


def reset_table_data(conn: sqlite3.Connection) -> None:
    conn.execute(f"DELETE FROM {TABLE_NAME};")


def create_item(conn: sqlite3.Connection, payload: dict[str, Any]) -> int:
    return create_row(conn, TABLE_NAME, payload, WRITABLE_COLUMNS)


def get_item(conn: sqlite3.Connection, item_id: int) -> dict[str, Any] | None:
    return get_row(conn, TABLE_NAME, PK_COLUMN, item_id)


def list_items(conn: sqlite3.Connection, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
    return list_rows(conn, TABLE_NAME, limit, offset)


def update_item(conn: sqlite3.Connection, item_id: int, payload: dict[str, Any]) -> bool:
    return update_row(conn, TABLE_NAME, PK_COLUMN, item_id, payload, WRITABLE_COLUMNS)


def delete_item(conn: sqlite3.Connection, item_id: int) -> bool:
    return delete_row(conn, TABLE_NAME, PK_COLUMN, item_id)
