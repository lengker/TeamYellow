from __future__ import annotations

import sqlite3
from collections import deque
from datetime import UTC, datetime
from typing import Any

from app.tables.registry import CREATION_ORDER, TABLE_MODULES

DEPENDENCY_GRAPH = {
    "airports": {"tracks", "vsp_data"},
    "users": {"annotations"},
    "tracks": {"audio_records"},
    "audio_records": {"annotations"},
    "annotations": set(),
    "vsp_data": set(),
    "storage_log": set(),
}


def _existing_tables(conn: sqlite3.Connection) -> set[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()
    return {row["name"] for row in rows}


def initialize_database(conn: sqlite3.Connection) -> None:
    existing = _existing_tables(conn)
    for table_key in CREATION_ORDER:
        module = TABLE_MODULES[table_key]
        if module.TABLE_NAME not in existing:
            module.create_table(conn)


def _descendants(table_key: str) -> set[str]:
    seen: set[str] = set()
    queue: deque[str] = deque([table_key])
    while queue:
        current = queue.popleft()
        for child in DEPENDENCY_GRAPH[current]:
            if child not in seen:
                seen.add(child)
                queue.append(child)
    return seen


def _child_to_parents() -> dict[str, set[str]]:
    parents: dict[str, set[str]] = {k: set() for k in TABLE_MODULES}
    for parent, children in DEPENDENCY_GRAPH.items():
        for child in children:
            parents[child].add(parent)
    return parents


def _ancestors(table_key: str) -> set[str]:
    if table_key not in TABLE_MODULES:
        raise KeyError(f"Unknown table key: {table_key}")
    child_to_parents = _child_to_parents()
    seen: set[str] = set()
    queue: deque[str] = deque(child_to_parents[table_key])
    while queue:
        current = queue.popleft()
        if current in seen:
            continue
        seen.add(current)
        for parent in child_to_parents[current]:
            if parent not in seen:
                queue.append(parent)
    return seen


def drop_tables_cascade(conn: sqlite3.Connection, table_key: str) -> list[str]:
    if table_key not in TABLE_MODULES:
        raise KeyError(f"Unknown table key: {table_key}")
    impacted = _descendants(table_key)
    impacted.add(table_key)
    drop_order = [key for key in reversed(CREATION_ORDER) if key in impacted]
    conn.execute("PRAGMA foreign_keys = OFF;")
    try:
        for key in drop_order:
            name = TABLE_MODULES[key].TABLE_NAME
            conn.execute(f"DROP TABLE IF EXISTS {name};")
    finally:
        conn.execute("PRAGMA foreign_keys = ON;")
    return drop_order


def ensure_tables_with_ancestors(
    conn: sqlite3.Connection, table_key: str
) -> list[dict[str, str]]:
    if table_key not in TABLE_MODULES:
        raise KeyError(f"Unknown table key: {table_key}")
    needed = _ancestors(table_key) | {table_key}
    ordered = [k for k in CREATION_ORDER if k in needed]
    existing_names = set(_existing_tables(conn))
    actions: list[dict[str, str]] = []
    for key in ordered:
        module = TABLE_MODULES[key]
        name = module.TABLE_NAME
        if name not in existing_names:
            module.create_table(conn)
            existing_names.add(name)
            actions.append({"key": key, "action": "created"})
        else:
            actions.append({"key": key, "action": "skipped"})
    return actions


def build_db_ui_snapshot(
    conn: sqlite3.Connection, row_limit: int = 100
) -> list[dict[str, Any]]:
    existing = _existing_tables(conn)
    out: list[dict[str, Any]] = []
    for table_key in CREATION_ORDER:
        module = TABLE_MODULES[table_key]
        sql_name = module.TABLE_NAME
        if sql_name not in existing:
            out.append(
                {
                    "key": table_key,
                    "sql_name": sql_name,
                    "exists": False,
                }
            )
            continue
        col_rows = conn.execute(f"PRAGMA table_info({sql_name})").fetchall()
        columns = [str(r["name"]) for r in col_rows]
        data_rows = conn.execute(
            f"SELECT * FROM {sql_name} LIMIT ?",
            (row_limit,),
        ).fetchall()
        out.append(
            {
                "key": table_key,
                "sql_name": sql_name,
                "exists": True,
                "columns": columns,
                "rows": [dict(r) for r in data_rows],
            }
        )
    return out


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _table_meta(conn: sqlite3.Connection, table_key: str) -> dict[str, Any]:
    if table_key not in TABLE_MODULES:
        raise KeyError(f"Unknown table key: {table_key}")
    module = TABLE_MODULES[table_key]
    table_name = module.TABLE_NAME
    if table_name not in _existing_tables(conn):
        raise ValueError(f"Table not created: {table_name}")
    info = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    columns = [str(x["name"]) for x in info]
    pk_col = next((str(x["name"]) for x in info if int(x["pk"]) == 1), module.PK_COLUMN)
    return {
        "module": module,
        "table_name": table_name,
        "columns": columns,
        "pk": pk_col,
    }


def _coerce_pk_value(module: Any, raw: Any) -> int | str:
    if raw is None:
        raise ValueError("Missing primary key value.")
    if module.PK_COLUMN.endswith("_id"):
        return int(raw)
    return str(raw)


def db_ui_create_row(conn: sqlite3.Connection, table_key: str, values: dict[str, Any]) -> dict[str, Any]:
    meta = _table_meta(conn, table_key)
    module = meta["module"]
    payload = dict(values)
    if table_key != "airports":
        payload.pop(module.PK_COLUMN, None)
    if table_key == "audio_records":
        payload["last_access_at"] = _now_iso()
    if table_key == "annotations":
        payload["annotation_time"] = _now_iso()
    item_id = module.create_item(conn, payload)
    return {"id": item_id}


def _detach_self_refs(conn: sqlite3.Connection, table_key: str, item_id: int | str) -> None:
    if table_key in {"tracks", "audio_records", "annotations"}:
        table_name = TABLE_MODULES[table_key].TABLE_NAME
        conn.execute(
            f"UPDATE {table_name} SET next_id = NULL WHERE next_id = ?",
            (item_id,),
        )
        conn.execute(
            f"UPDATE {table_name} SET prev_id = NULL WHERE prev_id = ?",
            (item_id,),
        )


def _log_audio_delete(conn: sqlite3.Connection, audio_id: int) -> None:
    conn.execute(
        """
        INSERT INTO LNG_STORAGE_LOG(action_type, target_file_id, released_space, op_time)
        VALUES (?, ?, ?, ?)
        """,
        ("CLEANUP", audio_id, 0, _now_iso()),
    )


def _delete_row_cascade(conn: sqlite3.Connection, table_key: str, item_id: int | str) -> bool:
    module = TABLE_MODULES[table_key]
    if module.get_item(conn, item_id) is None:
        return False

    if table_key == "airports":
        track_rows = conn.execute(
            """
            SELECT track_id FROM LNG_TRACKS
            WHERE departure_airport_code = ? OR arrival_airport_code = ?
            """,
            (item_id, item_id),
        ).fetchall()
        for row in track_rows:
            _delete_row_cascade(conn, "tracks", int(row["track_id"]))
        conn.execute("DELETE FROM LNG_VSP_DATA WHERE airport_code = ?", (item_id,))
    elif table_key == "users":
        ann_rows = conn.execute(
            "SELECT annotation_id FROM LNG_ANNOTATIONS WHERE author_id = ?",
            (item_id,),
        ).fetchall()
        for row in ann_rows:
            _delete_row_cascade(conn, "annotations", int(row["annotation_id"]))
    elif table_key == "tracks":
        audio_rows = conn.execute(
            "SELECT audio_id FROM LNG_AUDIO_RECORDS WHERE track_id = ?",
            (item_id,),
        ).fetchall()
        for row in audio_rows:
            _delete_row_cascade(conn, "audio_records", int(row["audio_id"]))
    elif table_key == "audio_records":
        ann_rows = conn.execute(
            "SELECT annotation_id FROM LNG_ANNOTATIONS WHERE audio_id = ?",
            (item_id,),
        ).fetchall()
        for row in ann_rows:
            _delete_row_cascade(conn, "annotations", int(row["annotation_id"]))
        _log_audio_delete(conn, int(item_id))

    _detach_self_refs(conn, table_key, item_id)
    return module.delete_item(conn, item_id)


def db_ui_delete_row(conn: sqlite3.Connection, table_key: str, pk_value: Any) -> dict[str, Any]:
    meta = _table_meta(conn, table_key)
    module = meta["module"]
    item_id = _coerce_pk_value(module, pk_value)
    deleted = _delete_row_cascade(conn, table_key, item_id)
    if not deleted:
        raise ValueError("Item not found.")
    return {"deleted": True, "id": item_id}


def _search_rows(
    conn: sqlite3.Connection,
    table_name: str,
    filters: dict[str, Any],
    limit: int,
) -> list[dict[str, Any]]:
    if not filters:
        rows = conn.execute(
            f"SELECT * FROM {table_name} LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]
    where = " AND ".join([f"{k} = ?" for k in filters])
    rows = conn.execute(
        f"SELECT * FROM {table_name} WHERE {where} LIMIT ?",
        tuple(filters.values()) + (limit,),
    ).fetchall()
    return [dict(r) for r in rows]


def db_ui_search_rows(
    conn: sqlite3.Connection,
    table_key: str,
    filters: dict[str, Any],
    limit: int = 100,
) -> dict[str, Any]:
    meta = _table_meta(conn, table_key)
    module = meta["module"]
    allowed = set(meta["columns"])
    cleaned = {
        k: v
        for k, v in filters.items()
        if k in allowed and k != module.PK_COLUMN and v not in (None, "")
    }
    rows = _search_rows(conn, meta["table_name"], cleaned, limit)
    if table_key == "audio_records" and rows:
        now = _now_iso()
        conn.execute(
            f"UPDATE {meta['table_name']} SET last_access_at = ? WHERE audio_id IN ({','.join(['?'] * len(rows))})",
            (now, *[int(r["audio_id"]) for r in rows]),
        )
        rows = _search_rows(conn, meta["table_name"], cleaned, limit)
    return {"rows": rows}


def _update_airport_key(
    conn: sqlite3.Connection,
    old_id: str,
    new_id: str,
) -> None:
    exists = conn.execute(
        "SELECT airport_code FROM LNG_AIRPORTS WHERE airport_code = ?",
        (new_id,),
    ).fetchone()
    if exists is not None:
        raise ValueError("New airport_code already exists.")
    conn.execute("PRAGMA foreign_keys = OFF;")
    try:
        conn.execute(
            "UPDATE LNG_AIRPORTS SET airport_code = ? WHERE airport_code = ?",
            (new_id, old_id),
        )
        conn.execute(
            "UPDATE LNG_TRACKS SET departure_airport_code = ? WHERE departure_airport_code = ?",
            (new_id, old_id),
        )
        conn.execute(
            "UPDATE LNG_TRACKS SET arrival_airport_code = ? WHERE arrival_airport_code = ?",
            (new_id, old_id),
        )
        conn.execute(
            "UPDATE LNG_VSP_DATA SET airport_code = ? WHERE airport_code = ?",
            (new_id, old_id),
        )
    finally:
        conn.execute("PRAGMA foreign_keys = ON;")


def db_ui_update_row(
    conn: sqlite3.Connection,
    table_key: str,
    pk_value: Any,
    values: dict[str, Any],
    new_pk_value: Any = None,
) -> dict[str, Any]:
    meta = _table_meta(conn, table_key)
    module = meta["module"]
    item_id = _coerce_pk_value(module, pk_value)
    if module.get_item(conn, item_id) is None:
        raise ValueError("Item not found.")
    payload = {
        k: v
        for k, v in values.items()
        if k in set(meta["columns"]) and k != module.PK_COLUMN
    }
    if table_key == "airports" and new_pk_value not in (None, ""):
        new_id = str(new_pk_value)
        if new_id != str(item_id):
            _update_airport_key(conn, str(item_id), new_id)
            item_id = new_id
    elif table_key != "airports":
        payload.pop(module.PK_COLUMN, None)

    if table_key == "audio_records":
        payload["last_access_at"] = _now_iso()
    if table_key == "annotations":
        payload["annotation_time"] = _now_iso()

    if payload:
        updated = module.update_item(conn, item_id, payload)
    else:
        updated = True
    if not updated:
        raise ValueError("Item not found or no fields changed")
    return {"updated": True, "id": item_id}


def reset_table_cascade(conn: sqlite3.Connection, table_key: str) -> list[str]:
    if table_key not in TABLE_MODULES:
        raise KeyError(f"Unknown table key: {table_key}")
    impacted = _descendants(table_key)
    impacted.add(table_key)

    clear_order = [key for key in reversed(CREATION_ORDER) if key in impacted]
    create_order = [key for key in CREATION_ORDER if key in impacted]

    for key in clear_order:
        TABLE_MODULES[key].reset_table_data(conn)
    for key in create_order:
        TABLE_MODULES[key].create_table(conn)

    return create_order


def reset_all_tables(conn: sqlite3.Connection) -> list[str]:
    for key in reversed(CREATION_ORDER):
        TABLE_MODULES[key].reset_table_data(conn)
    for key in CREATION_ORDER:
        TABLE_MODULES[key].create_table(conn)
    return list(CREATION_ORDER)
