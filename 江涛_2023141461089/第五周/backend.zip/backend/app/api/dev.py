from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.config import get_settings
from app.db.bootstrap import reset_all_tables, reset_table_cascade
from app.db.connection import get_connection
from app.tables.registry import TABLE_MODULES

router = APIRouter(prefix="/dev", tags=["dev"])


def _ensure_dev_mode() -> None:
    if not get_settings().is_dev:
        raise HTTPException(status_code=403, detail="Development endpoints are disabled.")


@router.post("/reset/{table_key}")
def reset_single_table(table_key: str) -> dict[str, object]:
    _ensure_dev_mode()
    if table_key not in TABLE_MODULES:
        raise HTTPException(status_code=404, detail="Unknown table")
    with get_connection() as conn:
        recreated = reset_table_cascade(conn, table_key)
    return {"reset": table_key, "recreated_order": recreated}


@router.post("/reset-all")
def reset_everything() -> dict[str, object]:
    _ensure_dev_mode()
    with get_connection() as conn:
        recreated = reset_all_tables(conn)
    return {"reset_all": True, "recreated_order": recreated}
