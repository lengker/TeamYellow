from __future__ import annotations

import sqlite3
from collections import deque

from app.tables.registry import CREATION_ORDER, TABLE_MODULES

DEPENDENCY_GRAPH = {
    "airports": {"tracks", "vsp_data"},
    "users": {"annotations"},
    "tracks": {"audio_records"},
    "audio_records": {"annotations"},
    "annotations": set(),
    "vsp_data": set(),
    "storage_log": set(),
}


def _existing_tables(conn: sqlite3.Connection) -> set[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()
    return {row["name"] for row in rows}


def initialize_database(conn: sqlite3.Connection) -> None:
    existing = _existing_tables(conn)
    for table_key in CREATION_ORDER:
        module = TABLE_MODULES[table_key]
        if module.TABLE_NAME not in existing:
            module.create_table(conn)


def _descendants(table_key: str) -> set[str]:
    seen: set[str] = set()
    queue: deque[str] = deque([table_key])
    while queue:
        current = queue.popleft()
        for child in DEPENDENCY_GRAPH[current]:
            if child not in seen:
                seen.add(child)
                queue.append(child)
    return seen


def reset_table_cascade(conn: sqlite3.Connection, table_key: str) -> list[str]:
    if table_key not in TABLE_MODULES:
        raise KeyError(f"Unknown table key: {table_key}")
    impacted = _descendants(table_key)
    impacted.add(table_key)

    clear_order = [key for key in reversed(CREATION_ORDER) if key in impacted]
    create_order = [key for key in CREATION_ORDER if key in impacted]

    for key in clear_order:
        TABLE_MODULES[key].reset_table_data(conn)
    for key in create_order:
        TABLE_MODULES[key].create_table(conn)

    return create_order


def reset_all_tables(conn: sqlite3.Connection) -> list[str]:
    for key in reversed(CREATION_ORDER):
        TABLE_MODULES[key].reset_table_data(conn)
    for key in CREATION_ORDER:
        TABLE_MODULES[key].create_table(conn)
    return list(CREATION_ORDER)
