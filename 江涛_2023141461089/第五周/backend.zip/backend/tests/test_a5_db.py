from __future__ import annotations

import importlib
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient


def _build_client(db_path: Path, env: str = "development") -> TestClient:
    import os

    os.environ["APP_DB_PATH"] = str(db_path)
    os.environ["APP_ENV"] = env
    module = importlib.import_module("app.main")
    module = importlib.reload(module)
    return TestClient(module.app)


def test_startup_is_idempotent(tmp_path: Path) -> None:
    db_path = tmp_path / "idempotent.sqlite3"

    with _build_client(db_path) as client:
        assert client.get("/health").status_code == 200
    with _build_client(db_path) as client:
        assert client.get("/health").status_code == 200

    conn = sqlite3.connect(str(db_path))
    count = conn.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name LIKE 'LNG_%'"
    ).fetchone()[0]
    conn.close()
    assert count == 7


def test_foreign_key_constraint(tmp_path: Path) -> None:
    db_path = tmp_path / "fk.sqlite3"
    with _build_client(db_path) as client:
        resp = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "latitude": 22.308,
                "longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        )
        assert resp.status_code == 400


def test_cascade_reset_for_parent_table(tmp_path: Path) -> None:
    db_path = tmp_path / "cascade.sqlite3"
    with _build_client(db_path) as client:
        client.post(
            "/tables/airports",
            json={"airport_code": "VHHH", "name": "Hong Kong"},
        )
        client.post(
            "/tables/airports",
            json={"airport_code": "ZBAA", "name": "Beijing"},
        )
        user_id = client.post(
            "/tables/users",
            json={"username": "alice", "password_hash": "x"},
        ).json()["id"]
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "latitude": 22.308,
                "longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]
        audio_id = client.post(
            "/tables/audio_records",
            json={
                "source_url": "https://example.com/a.wav",
                "start_time_utc": "2026-04-07T12:00:00Z",
                "end_time_utc": "2026-04-07T12:10:00Z",
                "duration_ms": 600000,
                "file_name": "a.wav",
                "file_path": "/tmp/a.wav",
                "track_id": track_id,
            },
        ).json()["id"]
        client.post(
            "/tables/annotations",
            json={"author_id": user_id, "audio_id": audio_id},
        )
        client.post(
            "/tables/vsp_data",
            json={"airport_code": "VHHH", "region": "HK"},
        )

        reset_resp = client.post("/dev/reset/airports")
        assert reset_resp.status_code == 200
        recreated_order = reset_resp.json()["recreated_order"]
        assert recreated_order == ["airports", "tracks", "audio_records", "annotations", "vsp_data"]

        assert client.get("/tables/airports").json() == []
        assert client.get("/tables/tracks").json() == []
        assert client.get("/tables/audio_records").json() == []
        assert client.get("/tables/annotations").json() == []
        assert client.get("/tables/vsp_data").json() == []
        assert len(client.get("/tables/users").json()) == 1


def test_basic_crud_users(tmp_path: Path) -> None:
    db_path = tmp_path / "crud.sqlite3"
    with _build_client(db_path) as client:
        created = client.post(
            "/tables/users",
            json={"username": "bob", "password_hash": "hash", "role": "annotator"},
        )
        assert created.status_code == 200
        user_id = created.json()["id"]

        fetched = client.get(f"/tables/users/{user_id}")
        assert fetched.status_code == 200
        assert fetched.json()["username"] == "bob"

        updated = client.put(f"/tables/users/{user_id}", json={"email": "bob@example.com"})
        assert updated.status_code == 200

        listed = client.get("/tables/users").json()
        assert len(listed) == 1
        assert listed[0]["email"] == "bob@example.com"

        deleted = client.delete(f"/tables/users/{user_id}")
        assert deleted.status_code == 200
        assert client.get(f"/tables/users/{user_id}").status_code == 404


def test_dev_endpoints_disabled_in_production(tmp_path: Path) -> None:
    db_path = tmp_path / "prod.sqlite3"
    with _build_client(db_path, env="production") as client:
        resp = client.post("/dev/reset-all")
        assert resp.status_code == 403
