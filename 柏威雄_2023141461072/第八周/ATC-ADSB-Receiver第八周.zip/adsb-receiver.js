// @ts-nocheck
class ADSBDataReceiver {
  constructor() {
      this.dataList = [];
  }

  // 处理航迹数据：绑定时间戳、存储
  handleData(raw) {
      try {
          // 兼容字符串和对象两种输入格式
          const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
          // 绑定A-1模块的接收时间戳
          data.timestamp = Date.now();
          this.dataList.push(data);
          console.log("📥 接收航迹数据：", data);
          return true;
      } catch (e) {
          console.error("❌ 数据处理失败", e);
          return false;
      }
  }

  getAdsbData() {
      return this.dataList;
  }
}

// 初始化接收器
const receiver = new ADSBDataReceiver();

// -------------------
// 修复：Node.js环境下的采集代码（加了请求头和错误处理）
// -------------------

// 你的OpenSky账号信息
const OPENSKY_USER = "baiweixiong";
const OPENSKY_PWD = "App3652410";

async function getFreeLive() {
  const params = { lamin: 40, lamax: 60, lomin: -10, lomax: 30 };
  try {
      console.log("正在采集航迹数据...");
      // 加浏览器请求头，防止被服务器拦截
      const res = await fetch(`https://opensky-network.org/api/states/all?lamin=${params.lamin}&lamax=${params.lamax}&lomin=${params.lomin}&lomax=${params.lomax}`, {
        headers: {
            // 生成Basic Auth的认证头
            'Authorization': 'Basic ' + Buffer.from(`${OPENSKY_USER}:${OPENSKY_PWD}`).toString('base64')
        }
    });

      if (!res.ok) throw new Error(`请求失败，状态码：${res.status}`);

      const data = await res.json();
      console.log("OpenSky完整返回：", data); 


      const aircraftList = data.states || [];
      console.log(`✅ 采集成功：当前空域 ${aircraftList.length} 架飞机`);


      // 把采集到的真实数据传给接收器处理
      aircraftList.forEach(aircraft => {
          const adsbData = {
            icao: aircraft[0],
            lat: aircraft[6],
            lon: aircraft[5],
            alt: aircraft[7],
            speed: aircraft[9]
          };
          receiver.handleData(adsbData);
      });
  } catch (e) {
      console.error("❌ 拉取航班数据失败", e.message);
  }
}



// 启动定时采集（每15秒拉一次，防止请求太频繁被拦截）
setInterval(getFreeLive, 15000);
console.log("✅ 已启动航迹采集程序，每15秒拉取一次数据");