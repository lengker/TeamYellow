from __future__ import annotations

import importlib
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient


def _build_client(db_path: Path, env: str = "development") -> TestClient:
    import os

    os.environ["APP_DB_PATH"] = str(db_path)
    os.environ["APP_ENV"] = env
    module = importlib.import_module("app.main")
    module = importlib.reload(module)
    return TestClient(module.app)


def test_startup_is_idempotent(tmp_path: Path) -> None:
    db_path = tmp_path / "idempotent.sqlite3"

    with _build_client(db_path) as client:
        assert client.get("/health").status_code == 200
    with _build_client(db_path) as client:
        assert client.get("/health").status_code == 200

    conn = sqlite3.connect(str(db_path))
    count = conn.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name LIKE 'LNG_%'"
    ).fetchone()[0]
    conn.close()
    assert count == 7


def test_foreign_key_constraint(tmp_path: Path) -> None:
    db_path = tmp_path / "fk.sqlite3"
    with _build_client(db_path) as client:
        resp = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        )
        assert resp.status_code == 400


def test_cascade_reset_for_parent_table(tmp_path: Path) -> None:
    db_path = tmp_path / "cascade.sqlite3"
    with _build_client(db_path) as client:
        client.post(
            "/tables/airports",
            json={"airport_code": "VHHH", "name": "Hong Kong"},
        )
        client.post(
            "/tables/airports",
            json={"airport_code": "ZBAA", "name": "Beijing"},
        )
        user_id = client.post(
            "/tables/users",
            json={"username": "alice", "password_hash": "x"},
        ).json()["id"]
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]
        audio_id = client.post(
            "/tables/audio_records",
            json={
                "source_url": "https://example.com/a.wav",
                "start_time_utc": "2026-04-07T12:00:00Z",
                "end_time_utc": "2026-04-07T12:10:00Z",
                "duration_ms": 600000,
                "file_name": "a.wav",
                "file_path": "/tmp/a.wav",
                "file_size": 2,
                "track_id": track_id,
            },
        ).json()["id"]
        client.post(
            "/tables/annotations",
            json={"author_id": user_id, "audio_id": audio_id},
        )
        client.post(
            "/tables/vsp_data",
            json={"airport_code": "VHHH", "region": "HK"},
        )

        reset_resp = client.post("/dev/reset/airports")
        assert reset_resp.status_code == 200
        recreated_order = reset_resp.json()["recreated_order"]
        assert recreated_order == ["airports", "tracks", "audio_records", "annotations", "vsp_data"]

        assert client.get("/tables/airports").json() == []
        assert client.get("/tables/tracks").json() == []
        assert client.get("/tables/audio_records").json() == []
        assert client.get("/tables/annotations").json() == []
        assert client.get("/tables/vsp_data").json() == []
        assert len(client.get("/tables/users").json()) == 1


def test_basic_crud_users(tmp_path: Path) -> None:
    db_path = tmp_path / "crud.sqlite3"
    with _build_client(db_path) as client:
        created = client.post(
            "/tables/users",
            json={"username": "bob", "password_hash": "hash", "role": "annotator"},
        )
        assert created.status_code == 200
        user_id = created.json()["id"]

        fetched = client.get(f"/tables/users/{user_id}")
        assert fetched.status_code == 200
        assert fetched.json()["username"] == "bob"

        updated = client.put(f"/tables/users/{user_id}", json={"email": "bob@example.com"})
        assert updated.status_code == 200

        listed = client.get("/tables/users").json()
        assert len(listed) == 1
        assert listed[0]["email"] == "bob@example.com"

        deleted = client.delete(f"/tables/users/{user_id}")
        assert deleted.status_code == 200
        assert client.get(f"/tables/users/{user_id}").status_code == 404


def test_dev_endpoints_disabled_in_production(tmp_path: Path) -> None:
    db_path = tmp_path / "prod.sqlite3"
    with _build_client(db_path, env="production") as client:
        resp = client.post("/dev/reset-all")
        assert resp.status_code == 403


def test_db_ui_audio_timestamps_and_search(tmp_path: Path) -> None:
    db_path = tmp_path / "db_ui_audio.sqlite3"
    with _build_client(db_path) as client:
        client.post("/tables/airports", json={"airport_code": "VHHH", "name": "Hong Kong"})
        client.post("/tables/airports", json={"airport_code": "ZBAA", "name": "Beijing"})
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]

        create_resp = client.post(
            "/dev/db-ui/rows/create/audio_records",
            json={
                "values": {
                    "source_url": "https://example.com/a.wav",
                    "start_time_utc": "2026-04-07T12:00:00Z",
                    "end_time_utc": "2026-04-07T12:10:00Z",
                    "duration_ms": 600000,
                    "file_name": "a.wav",
                    "file_path": "/tmp/a.wav",
                    "track_id": track_id,
                }
            },
        )
        assert create_resp.status_code == 200
        audio_id = create_resp.json()["id"]
        created = client.get(f"/tables/audio_records/{audio_id}").json()
        assert created["last_access_at"] is not None

        search_resp = client.post(
            "/dev/db-ui/rows/search/audio_records",
            json={"filters": {"track_id": track_id}},
        )
        assert search_resp.status_code == 200
        rows = search_resp.json()["rows"]
        assert len(rows) == 1
        assert rows[0]["last_access_at"] is not None


def test_db_ui_delete_audio_writes_storage_log(tmp_path: Path) -> None:
    db_path = tmp_path / "db_ui_delete_audio.sqlite3"
    with _build_client(db_path) as client:
        client.post("/tables/airports", json={"airport_code": "VHHH", "name": "Hong Kong"})
        client.post("/tables/airports", json={"airport_code": "ZBAA", "name": "Beijing"})
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]
        audio_id = client.post(
            "/tables/audio_records",
            json={
                "source_url": "https://example.com/a.wav",
                "start_time_utc": "2026-04-07T12:00:00Z",
                "end_time_utc": "2026-04-07T12:10:00Z",
                "duration_ms": 600000,
                "file_name": "a.wav",
                "file_path": "/tmp/a.wav",
                "file_size": 2,
                "track_id": track_id,
            },
        ).json()["id"]
        user_id = client.post(
            "/tables/users",
            json={"username": "alice2", "password_hash": "x"},
        ).json()["id"]
        client.post("/tables/annotations", json={"author_id": user_id, "audio_id": audio_id})

        del_resp = client.post("/dev/db-ui/rows/delete/audio_records", json={"id": audio_id})
        assert del_resp.status_code == 200
        assert client.get(f"/tables/audio_records/{audio_id}").status_code == 404
        assert client.get("/tables/annotations").json() == []
        logs = client.get("/tables/storage_log").json()
        assert len(logs) >= 1
        assert logs[-1]["action_type"] == "CLEANUP"
        assert logs[-1]["source_url"] == "https://example.com/a.wav"
        assert logs[-1]["released_space"] == 2


def test_db_ui_update_airport_pk_cascade(tmp_path: Path) -> None:
    db_path = tmp_path / "db_ui_update_airport.sqlite3"
    with _build_client(db_path) as client:
        client.post("/tables/airports", json={"airport_code": "VHHH", "name": "Hong Kong"})
        client.post("/tables/airports", json={"airport_code": "ZBAA", "name": "Beijing"})
        client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        )
        client.post("/tables/vsp_data", json={"airport_code": "VHHH", "region": "HK"})

        update_resp = client.post(
            "/dev/db-ui/rows/update/airports",
            json={"id": "VHHH", "new_id": "VHHX", "values": {"name": "Hong Kong X"}},
        )
        assert update_resp.status_code == 200
        assert client.get("/tables/airports/VHHH").status_code == 404
        airport = client.get("/tables/airports/VHHX").json()
        assert airport["name"] == "Hong Kong X"
        tracks = client.get("/tables/tracks").json()
        assert tracks[0]["departure_airport_code"] == "VHHX"
        vsp_rows = client.get("/tables/vsp_data").json()
        assert vsp_rows[0]["airport_code"] == "VHHX"


def test_query_arbitrary_cross_table_airport_name(tmp_path: Path) -> None:
    db_path = tmp_path / "query_arbitrary.sqlite3"
    with _build_client(db_path) as client:
        client.post(
            "/tables/airports",
            json={"airport_code": "VHHH", "name": "Hong Kong", "airports_latitude": 22.3, "airports_longitude": 113.9},
        )
        client.post(
            "/tables/airports",
            json={"airport_code": "ZBAA", "name": "Beijing", "airports_latitude": 40.0, "airports_longitude": 116.4},
        )
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]
        client.post(
            "/tables/audio_records",
            json={
                "source_url": "https://example.com/a.wav",
                "start_time_utc": "2026-04-07T12:00:00Z",
                "end_time_utc": "2026-04-07T12:10:00Z",
                "duration_ms": 600000,
                "file_name": "a.wav",
                "file_path": "/tmp/a.wav",
                "file_size": 2,
                "track_id": track_id,
            },
        )

        resp = client.post(
            "/query/arbitrary",
            json={"reference": {"file_size": 2, "source_url": "https://example.com/a.wav"}, "select": ["name"]},
        )
        assert resp.status_code == 200
        rows = resp.json()
        names = {r["name"] for r in rows}
        assert names == {"Hong Kong", "Beijing"}


def test_query_arbitrary_invalid_field(tmp_path: Path) -> None:
    db_path = tmp_path / "query_arbitrary_invalid.sqlite3"
    with _build_client(db_path) as client:
        resp = client.post(
            "/query/arbitrary",
            json={"reference": {"not_exists_field": 1}, "select": ["name"]},
        )
        assert resp.status_code == 400


def test_query_arbitrary_empty_result(tmp_path: Path) -> None:
    db_path = tmp_path / "query_arbitrary_empty.sqlite3"
    with _build_client(db_path) as client:
        client.post(
            "/tables/airports",
            json={"airport_code": "VHHH", "name": "Hong Kong", "airports_latitude": 22.3, "airports_longitude": 113.9},
        )
        client.post(
            "/tables/airports",
            json={"airport_code": "ZBAA", "name": "Beijing", "airports_latitude": 40.0, "airports_longitude": 116.4},
        )
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]
        client.post(
            "/tables/audio_records",
            json={
                "source_url": "https://example.com/a.wav",
                "start_time_utc": "2026-04-07T12:00:00Z",
                "end_time_utc": "2026-04-07T12:10:00Z",
                "duration_ms": 600000,
                "file_name": "a.wav",
                "file_path": "/tmp/a.wav",
                "file_size": 2,
                "track_id": track_id,
            },
        )

        resp = client.post(
            "/query/arbitrary",
            json={
                "reference": {"file_size": 9999, "source_url": "https://example.com/a.wav"},
                "select": ["name"],
            },
        )
        assert resp.status_code == 200
        assert resp.json() == []


def test_query_arbitrary_select_across_tables(tmp_path: Path) -> None:
    db_path = tmp_path / "query_arbitrary_select_cross_tables.sqlite3"
    with _build_client(db_path) as client:
        client.post(
            "/tables/airports",
            json={"airport_code": "VHHH", "name": "Hong Kong", "airports_latitude": 22.3, "airports_longitude": 113.9},
        )
        client.post(
            "/tables/airports",
            json={"airport_code": "ZBAA", "name": "Beijing", "airports_latitude": 40.0, "airports_longitude": 116.4},
        )
        track_id = client.post(
            "/tables/tracks",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX001",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "departure_airport_code": "VHHH",
                "arrival_airport_code": "ZBAA",
            },
        ).json()["id"]
        audio_id = client.post(
            "/tables/audio_records",
            json={
                "source_url": "https://example.com/a.wav",
                "start_time_utc": "2026-04-07T12:00:00Z",
                "end_time_utc": "2026-04-07T12:10:00Z",
                "duration_ms": 600000,
                "file_name": "a.wav",
                "file_path": "/tmp/a.wav",
                "file_size": 2,
                "track_id": track_id,
            },
        ).json()["id"]
        user_id = client.post(
            "/tables/users",
            json={"username": "alice", "password_hash": "x"},
        ).json()["id"]
        client.post("/tables/annotations", json={"author_id": user_id, "audio_id": audio_id})

        resp = client.post(
            "/query/arbitrary",
            json={
                "reference": {"file_size": 2, "source_url": "https://example.com/a.wav"},
                "select": ["name", "username"],
            },
        )
        assert resp.status_code == 200
        rows = resp.json()
        assert {r["username"] for r in rows} == {"alice"}
        assert {r["name"] for r in rows} == {"Hong Kong", "Beijing"}


def _seed_tracks_airports(client: TestClient) -> None:
    client.post("/tables/airports", json={"airport_code": "VHHH", "name": "Hong Kong"})
    client.post("/tables/airports", json={"airport_code": "VVTS", "name": "Ho Chi Minh"})
    client.post("/tables/airports", json={"airport_code": "ZBAA", "name": "Beijing"})
    client.post("/tables/airports", json={"airport_code": "RJTT", "name": "Tokyo"})


def test_tracks_ext_create_search_update_delete_stable(tmp_path: Path) -> None:
    db_path = tmp_path / "tracks_ext_stable.sqlite3"
    with _build_client(db_path) as client:
        _seed_tracks_airports(client)

        create_resp = client.post(
            "/tables/tracks/ext/create",
            json={
                "timestamp": "2026-04-07T12:00:00Z",
                "flight_id": "CX100",
                "tracks_latitude": 22.308,
                "tracks_longitude": 113.918,
                "altitude": 30000,
                "speed": 850,
                "heading": 90,
                "airport_code": ["VHHH", "VVTS", "ZBAA"],
            },
        )
        assert create_resp.status_code == 200
        created_ids = create_resp.json()["track_id"]
        assert len(created_ids) == 2

        rows = client.get("/tables/tracks").json()
        assert len(rows) == 2
        assert rows[0]["prev_id"] is None
        assert rows[0]["next_id"] == rows[1]["track_id"]
        assert rows[1]["prev_id"] == rows[0]["track_id"]
        assert rows[1]["next_id"] is None

        search_resp = client.post(
            "/tables/tracks/ext/search",
            json={"filters": {"flight_id": "CX100"}},
        )
        assert search_resp.status_code == 200
        aggregated = search_resp.json()
        assert aggregated["track_id"] == created_ids
        assert aggregated["airport_code"] == ["VHHH", "VVTS", "ZBAA"]

        update_resp = client.post(
            f"/tables/tracks/ext/update/{created_ids[0]}",
            json={
                "speed": 900,
                "arrival_airport_code": "RJTT",
            },
        )
        assert update_resp.status_code == 200
        updated_rows = client.get("/tables/tracks").json()
        assert {row["speed"] for row in updated_rows} == {900.0}
        first_row = next(row for row in updated_rows if row["track_id"] == created_ids[0])
        second_row = next(row for row in updated_rows if row["track_id"] == created_ids[1])
        assert first_row["arrival_airport_code"] == "RJTT"
        assert second_row["departure_airport_code"] == "RJTT"

        blocked_resp = client.post(
            f"/tables/tracks/ext/update/{created_ids[0]}",
            json={"next_id": 999},
        )
        assert blocked_resp.status_code == 400

        delete_resp = client.post("/tables/tracks/ext/delete", json={"id": created_ids[1]})
        assert delete_resp.status_code == 200
        assert delete_resp.json()["ids"] == created_ids
        assert client.get("/tables/tracks").json() == []


def test_tracks_ext_create_search_update_delete_dev(tmp_path: Path) -> None:
    db_path = tmp_path / "tracks_ext_dev.sqlite3"
    with _build_client(db_path) as client:
        _seed_tracks_airports(client)

        create_resp = client.post(
            "/dev/db-ui/rows/tracks/ext/create",
            json=[
                {
                    "timestamp": "2026-04-07T13:00:00Z",
                    "flight_id": "CX200",
                    "tracks_latitude": 22.308,
                    "tracks_longitude": 113.918,
                    "altitude": 31000,
                    "speed": 800,
                    "heading": 45,
                    "airport_code": ["VHHH", "VVTS", "ZBAA"],
                },
                {
                    "timestamp": "2026-04-07T14:00:00Z",
                    "flight_id": "CX201",
                    "tracks_latitude": 35.5,
                    "tracks_longitude": 139.7,
                    "altitude": 28000,
                    "speed": 780,
                    "heading": 120,
                    "airport_code": ["RJTT", "ZBAA"],
                },
            ],
        )
        assert create_resp.status_code == 200
        created = create_resp.json()
        assert len(created) == 2
        first_chain_ids = created[0]["track_id"]
        second_chain_id = created[1]["track_id"]
        assert len(first_chain_ids) == 2
        assert isinstance(second_chain_id, int)

        search_resp = client.post("/dev/db-ui/rows/tracks/ext/search", json={"filters": {}})
        assert search_resp.status_code == 200
        aggregated = search_resp.json()
        assert isinstance(aggregated, list)
        assert len(aggregated) == 2

        update_resp = client.post(
            "/dev/db-ui/rows/tracks/ext/update",
            json={
                "id": first_chain_ids[1],
                "values": {
                    "departure_airport_code": "RJTT",
                    "altitude": 32000,
                },
            },
        )
        assert update_resp.status_code == 200
        rows = client.get("/tables/tracks").json()
        first_row = next(row for row in rows if row["track_id"] == first_chain_ids[0])
        second_row = next(row for row in rows if row["track_id"] == first_chain_ids[1])
        assert first_row["arrival_airport_code"] == "RJTT"
        assert second_row["departure_airport_code"] == "RJTT"
        assert {row["altitude"] for row in rows if row["track_id"] in first_chain_ids} == {32000.0}

        delete_resp = client.post(
            "/dev/db-ui/rows/tracks/ext/delete",
            json={"id": first_chain_ids[0]},
        )
        assert delete_resp.status_code == 200
        remaining = client.get("/tables/tracks").json()
        assert len(remaining) == 1
        assert remaining[0]["track_id"] == second_chain_id
