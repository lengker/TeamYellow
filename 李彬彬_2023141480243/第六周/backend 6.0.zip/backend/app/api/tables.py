from __future__ import annotations

import sqlite3
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from app.db.connection import get_connection
from app.tables.registry import TABLE_MODULES

router = APIRouter(prefix="/tables", tags=["tables"])


def _parse_item_id(module: Any, item_id: str) -> int | str:
    if module.PK_COLUMN.endswith("_id"):
        return int(item_id)
    return item_id


@router.post("/{table_key}")
def create_item(table_key: str, payload: dict[str, Any]) -> dict[str, Any]:
    if table_key not in TABLE_MODULES:
        raise HTTPException(status_code=404, detail="Unknown table")
    module = TABLE_MODULES[table_key]
    try:
        with get_connection() as conn:
            item_id = module.create_item(conn, payload)
    except (sqlite3.IntegrityError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"id": item_id}


@router.get("/{table_key}/{item_id}")
def get_item(table_key: str, item_id: str) -> dict[str, Any]:
    if table_key not in TABLE_MODULES:
        raise HTTPException(status_code=404, detail="Unknown table")
    module = TABLE_MODULES[table_key]
    parsed_id = _parse_item_id(module, item_id)
    with get_connection() as conn:
        row = module.get_item(conn, parsed_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Item not found")
    return row


@router.get("/{table_key}")
def list_items(
    table_key: str,
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
) -> list[dict[str, Any]]:
    if table_key not in TABLE_MODULES:
        raise HTTPException(status_code=404, detail="Unknown table")
    module = TABLE_MODULES[table_key]
    with get_connection() as conn:
        return module.list_items(conn, limit=limit, offset=offset)


@router.put("/{table_key}/{item_id}")
def update_item(table_key: str, item_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    if table_key not in TABLE_MODULES:
        raise HTTPException(status_code=404, detail="Unknown table")
    module = TABLE_MODULES[table_key]
    parsed_id = _parse_item_id(module, item_id)
    try:
        with get_connection() as conn:
            updated = module.update_item(conn, parsed_id, payload)
    except sqlite3.IntegrityError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not updated:
        raise HTTPException(status_code=404, detail="Item not found or no fields changed")
    return {"updated": True}


@router.delete("/{table_key}/{item_id}")
def delete_item(table_key: str, item_id: str) -> dict[str, Any]:
    if table_key not in TABLE_MODULES:
        raise HTTPException(status_code=404, detail="Unknown table")
    module = TABLE_MODULES[table_key]
    parsed_id = _parse_item_id(module, item_id)
    with get_connection() as conn:
        deleted = module.delete_item(conn, parsed_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"deleted": True}
