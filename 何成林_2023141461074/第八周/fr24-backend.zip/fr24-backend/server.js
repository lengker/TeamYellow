// @ts-nocheck
class ADSBDataReceiver {
  constructor() {
      this.dataList = [];
  }

  // 处理航迹数据：绑定时间戳、存储
  handleData(raw) {
      try {
          // 兼容字符串和对象两种输入格式
          const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
          // 绑定A-1模块的接收时间戳
          data.timestamp = Date.now();
          this.dataList.push(data);
          console.log("📥 接收航迹数据：", data);
          return true;
      } catch (e) {
          console.error("❌ 数据处理失败", e);
          return false;
      }
  }

  getAdsbData() {
      return this.dataList;
  }
}

// 初始化接收器
const receiver = new ADSBDataReceiver();

// -------------------
// 修复：Node.js环境下的采集代码（加了请求头和错误处理）
// -------------------
async function getFreeLive() {
  const params = { lamin: 30, lamax: 32, lomin: 120, lomax: 122 };
  try {
      // 加浏览器请求头，防止被服务器拦截
      const res = await fetch(`https://opensky-network.org/api/states/all?lamin=${params.lamin}&lamax=${params.lamax}&lomin=${params.lomin}&lomax=${params.lomax}`, {
          headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
          }
      });

      if (!res.ok) throw new Error(`请求失败，状态码：${res.status}`);

      const data = await res.json();
      console.log("OpenSky完整返回：", data); 


      const aircraftList = data.aircraft || [];
      console.log(`✅ 采集成功：当前空域 ${aircraftList.length} 架飞机`);


      // 把采集到的真实数据传给接收器处理
      aircraftList.forEach(aircraft => {
          const adsbData = {
              icao: aircraft.icao,
              callsign: aircraft.callsign,
              lat: aircraft.lat,
              lon: aircraft.lon,
              alt: aircraft.alt,
              speed: aircraft.spd
          };
          receiver.handleData(adsbData);
      });
  } catch (e) {
      console.error("❌ 拉取航班数据失败", e.message);
  }
}

// 备用：拉取单航班航迹
async function getFreeTrack(flightId) {
  try {
      const res = await fetch(`https://data.flightradar24.com/tracks/${flightId}.json`, {
          headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
          }
      });
      if (!res.ok) throw new Error(`请求失败，状态码：${res.status}`);
      const data = await res.json();
      console.log('✅ 单航班航迹：', data.tracks);
  } catch (e) {
      console.error("❌ 拉取单航班航迹失败", e.message);
  }
}

// 启动定时采集（每10秒拉一次，防止请求太频繁被拦截）
setInterval(getFreeLive, 10000);
console.log("✅ 已启动航迹采集程序，每10秒拉取一次数据");