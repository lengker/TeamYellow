# A-3 模块数据库连接池与 DAO 模式基建 (第 5 周)

## 1. 项目概述
本周完成了 A-3 语音预处理模块底层数据库抽象层的全面构建与重构。通过引入 **SQLAlchemy 连接池** 与 **DAO (Data Access Object) 模式**，解决了高并发场景下的连接效率问题，并实现了业务逻辑与数据库访问的深度解耦。同时，通过自动化压测脚本验证了系统在高并发下的稳定性。

## 2. 完善后的目录结构

```text
homework/
├── app/
│   ├── core/
│   │   └── config.py          # 【配置层】使用 Pydantic 管理数据库 URL 及连接池调优参数
│   ├── db/
│   │   ├── base.py            # 【声明层】定义 ORM 模型基类 Base
│   │   └── session.py         # 【引擎层】初始化连接池并提供 get_db 安全会话生成器
│   ├── models/
│   │   └── a3_models.py       # 【模型层】定义 LNG_TRACKS 与 LNG_AUDIO_RECORDS 业务表结构
│   └── crud/
│       └── a3_crud.py         # 【DAO 层】封装核心业务的增删改查逻辑，废弃直连代码
├── scripts/
│   └── test_db_pool_pressure.py # 【测试层】多线程高并发压力测试脚本，验证连接池性能
└── README.md                  # 项目说明文档