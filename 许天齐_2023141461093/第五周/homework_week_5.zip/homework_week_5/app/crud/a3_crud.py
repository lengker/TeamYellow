# homework/app/crud/a3_crud.py
from sqlalchemy.orm import Session
from sqlalchemy import and_
from datetime import datetime
from app.models.a3_models import LngAudioRecords, LngTracks

# ==========================================
# LngAudioRecords (语音记录表) 相关 DAO 操作
# ==========================================

def create_audio_record(db: Session, record_data: dict) -> LngAudioRecords:
    """
    新建一条语音识别记录
    :param db: 数据库会话 (由连接池生成)
    :param record_data: 包含文件信息的字典
    """
    db_record = LngAudioRecords(**record_data)
    db.add(db_record)
    db.commit()
    db.refresh(db_record) # 刷新以获取数据库自增的 ID
    return db_record

def get_audio_record_by_id(db: Session, record_id: int):
    """根据 ID 查询单条语音记录"""
    return db.query(LngAudioRecords).filter(LngAudioRecords.id == record_id).first()

def get_audio_records_by_time_range(db: Session, start_time: datetime, end_time: datetime, skip: int = 0, limit: int = 20):
    """
    对标接口文档 RQ-A-3-30：按起止时间查询地空通话
    包含分页逻辑 (skip, limit)
    """
    return db.query(LngAudioRecords).filter(
        and_(
            LngAudioRecords.created_at >= start_time,
            LngAudioRecords.created_at <= end_time
        )
    ).offset(skip).limit(limit).all()

# ==========================================
# LngTracks (航迹表) 相关 DAO 操作
# ==========================================

def create_track(db: Session, track_data: dict) -> LngTracks:
    """写入一条航迹数据"""
    db_track = LngTracks(**track_data)
    db.add(db_track)
    db.commit()
    db.refresh(db_track)
    return db_track