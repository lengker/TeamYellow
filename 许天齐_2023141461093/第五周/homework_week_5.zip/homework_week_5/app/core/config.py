import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # 数据库配置：格式为 mysql+pymysql://用户名:密码@地址:端口/数据库名
    DATABASE_URL: str = os.getenv("DATABASE_URL", "mysql+pymysql://root:123456@localhost:3306/atc_a3_db")

    # 连接池参数 [针对 A-3 语音数据吞吐量调优]
    DB_POOL_SIZE: int = 10  # 基础连接数
    DB_MAX_OVERFLOW: int = 20  # 最大允许溢出连接数
    DB_POOL_RECYCLE: int = 3600  # 连接回收时间(秒)
    DB_POOL_PRE_PING: bool = True  # 借出连接前先检查存活


settings = Settings()