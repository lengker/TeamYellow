from sqlalchemy import Column, String, Integer, Float, DateTime, Text, ForeignKey
from datetime import datetime
from app.db.base import Base


class LngTracks(Base):
    """1.1.1.1.1. LNG_TRACKS (航迹表)"""
    __tablename__ = "LNG_TRACKS"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    callsign = Column(String(20), index=True, comment="航班呼号")
    latitude = Column(Float, nullable=False, comment="纬度")
    longitude = Column(Float, nullable=False, comment="经度")
    altitude = Column(Float, comment="高度")
    timestamp = Column(DateTime, default=datetime.now, comment="数据产生时间")


class LngAudioRecords(Base):
    """1.1.1.1.1. LNG_AUDIO_RECORDS (原始音频表/t_a2_voice_files)"""
    __tablename__ = "LNG_AUDIO_RECORDS"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    file_name = Column(String(255), nullable=False, comment="文件名")
    file_path = Column(String(512), nullable=False, comment="存储绝对路径")
    duration = Column(Float, comment="音频时长(s)")
    asr_content = Column(Text, comment="ASR识别原始文本")
    ground_truth = Column(Text, comment="人工校对标准文本")
    created_at = Column(DateTime, default=datetime.now)
    channel = Column(String(50), comment="所属频道(APP/TWR等)")